# magicpin AI Challenge — Submission

**Team:** Aish (solo)
**Approach:** deterministic, template + real-data composer (no live LLM call by default)

## What's in this submission

| File | Purpose |
|---|---|
| `bot.py` | The bot: `compose()` (the required §7.1 contract) + a FastAPI app exposing all 5 endpoints from the testing brief (`/v1/context`, `/v1/tick`, `/v1/reply`, `/v1/healthz`, `/v1/metadata`), plus the conversation FSM. |
| `submission.jsonl` | 30 lines, one per canonical test pair in `test_pairs.json`, produced by literally calling `bot.compose()` — not hand-written, so it's guaranteed to match what the live bot returns for the same inputs. |
| `conversation_handlers.py` | Optional multi-turn `respond(state, merchant_message)` wrapper around the same FSM used by `/v1/reply`. |
| `generate_submission.py` | The script that built `submission.jsonl` from the expanded dataset — re-run it any time the dataset or `bot.py` changes. |
| `requirements.txt` | `fastapi`, `uvicorn`, `pydantic`. |

## How to run it

```bash
pip install -r requirements.txt
uvicorn bot:app --host 0.0.0.0 --port 8080
```

To rebuild `submission.jsonl` from scratch against the canonical dataset:

```bash
python dataset/generate_dataset.py --seed-dir dataset --out ./expanded
python generate_submission.py --dataset ./expanded --out ./submission.jsonl
```

(`generate_dataset.py` is deterministic — fixed seed — so this reproduces the exact same 50 merchants / 200 customers / 100 triggers / 30 test pairs every participant gets.)

## Approach

Every one of the 25 trigger `kind`s in the dataset gets its own composer function. Each one:

1. **Prefers the trigger's own rich payload** when the judge provides one (e.g. `research_digest`'s `top_item_id`, `perf_dip`'s `metric`/`delta_pct`, `recall_due`'s `available_slots`).
2. **Falls back to real merchant/category facts** when the payload is a placeholder (about 60% of the generated triggers are placeholders with no specific numbers) — e.g. a placeholder `perf_dip` pulls the actual `delta_7d` from the merchant's own performance snapshot; a placeholder `research_digest` pulls the freshest real item off the category's `digest` list; a placeholder `competitor_opened` never invents a competitor name, and instead pivots to the merchant's own real CTR-vs-peer gap.

This means the bot is never faced with a choice between "say something generic" and "make something up" — it always has *some* real fact to anchor on, which is what the specificity/anti-fabrication scoring dimensions are actually rewarding.

**Language:** if `merchant.identity.languages` (or, for customer-facing sends, `customer.identity.language_pref`) contains `"hi"`, connective phrasing switches to Hindi-English code-mix (matching the brief's Pattern A/B examples); numbers, prices, and proper nouns stay in Latin script, which is how this actually reads in real WhatsApp business chat.

**Conversation FSM** (`decide_reply`, shared by `/v1/reply` and `conversation_handlers.respond`):
- Verbatim repeat or a canned-phrase match (`"thank you for contacting"`, `"team tak pahuncha"`, etc.) → one polite nudge on the first hit, graceful `end` on the second (avoids burning turns on WhatsApp Business auto-replies).
- Explicit commitment language (`"yes"`, `"let's do it"`, `"haan"`, `"theek hai"`) → switches straight to **action** mode, never re-qualifies (this is the #1 anti-pattern called out in the brief).
- Hostile/"stop" language → polite `end`, no further nudges.
- An unrelated question (GST, tax, loan, …) → one-line redirect, stays on-mission, does **not** end the conversation.
- Otherwise → a single low-friction binary "want me to go ahead, or more detail first?" to keep the conversation moving.

**Anti-repetition / anti-spam:** `/v1/tick` tracks which `suppression_key`s have already been sent per merchant and never re-fires the same nudge; `/v1/reply` checks the candidate body against everything already sent in that conversation and appends a short variation if it would otherwise repeat verbatim.

## Trade-offs

- **No live LLM call.** I chose a template composer over wiring up an actual LLM API call so the bot is trivially deterministic (the brief requires `temperature=0`-equivalent determinism), has zero external-API latency/failure risk against the 30-second budget, and can't hallucinate — every clause in every template traces back to a specific field in the pushed context. The cost is that phrasing is less varied than a frontier model would produce, and 25 hand-written kind-handlers is more code than one good prompt. `compose()` is structured so a real LLM call could be dropped in per trigger-kind (or as a final polish pass over the template output) without touching the FastAPI wiring or the anti-fabrication guardrails.
- **Multi-turn FSM is rule-based, not a state machine over full dialogue history** — it looks at the latest message plus a short auto-reply-strike counter, not a full re-derivation of merchant intent from the whole thread. This covers the three replay-test scenarios in the brief (auto-reply hell, intent transition, hostile) but a longer, more meandering conversation (5+ turns of genuine back-and-forth) would benefit from feeding the accumulated history into an LLM call rather than pattern-matching each turn in isolation.
- **`curious_ask_due`'s `ask_template` field** in the dataset is a snake_case identifier (e.g. `what_service_in_demand_this_week`), not display-ready text, and there's no template library shipped to resolve it against — I humanize it into a question rather than treat it as literal copy, or fall back to a category-appropriate default question when there's nothing usable.

## What additional context would have helped most

1. **A resolvable template library for `ask_template` / similar slug-style payload fields** (or a note that they're internal IDs and should be ignored) — right now I have to guess whether a payload string is meant to be shown verbatim or is an internal key.
2. **Explicit `send_as`/attribution guidance for triggers where `scope == "customer"` but the message is really about the merchant's own account** (none in this dataset, but the schema allows for it) — the current rule (customer present → `merchant_on_behalf`) is a reasonable default but the brief doesn't fully spell out edge cases.
3. **A few labeled "good" vs "bad" example outputs per trigger `kind`** (the brief only gives full worked examples for `research_digest` and `recall_due` in the appendices) — extending that pattern to a couple more kinds (e.g. `competitor_opened`, `perf_dip`) would have removed some guesswork on tone calibration for kinds with sparse examples.
